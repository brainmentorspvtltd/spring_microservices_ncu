package com.brainmentors.orm;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDAO employeeDAO = new EmployeeDAO();
		//employeeDAO.save();
		employeeDAO.read(78878);
		//employeeDAO.remove(1001);
		//employeeDAO.update(1002);

	}

}
