package com.brainmentors.apps.hqleg;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//       Customer customer = new Customer("Ram",2222,"Delhi");
//       DAO.save(customer);
//       DAO.save(new Customer("Shyam",3333,"Delhi"));
//       DAO.save(new Customer("Tim",13333,"Mumbai"));
//       DAO.save(new Customer("Kim",23333,"Delhi"));
//       DAO.save(new Customer("Sim",33333,"Mumbai"));
//       DAO.save(new Customer("Rim",43333,"Delhi"));
//       DAO.save(new Customer("Vim",53333,"Mumbai"));
       
       //DAO.getCustomer(2);
    	//DAO.getCustomers();
    	//DAO.updateCustomers();
    	//DAO.getCustomerProjection();
    	//DAO.getCustomerProjectionWhere();
    	//DAO.getCustomerOrderBy();
    	//DAO.getCustomerOrderByMultiple();
    	//DAO.groupBy();
    	//DAO.agg();
    	//DAO.sqlInjection("5435345345435 or 1=1");
    	//DAO.parameterWayPosition("9000");
    	//DAO.parameterWayNamed("9000");
    	//DAO.findByCustomerId(1);
    	//System.out.println("################################");
    	//DAO.sortedRecords();
    	//DAO.callNamedNativeQuery(200);
    	//DAO.criteria();
    	//DAO.firstLevelCache(1);
    	DAO.secondLevelCache(1);
    }
}
