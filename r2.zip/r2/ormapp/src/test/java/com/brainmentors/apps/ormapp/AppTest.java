package com.brainmentors.apps.ormapp;




/**
 * Unit test for simple App.
 */
public class AppTest {

}
