package com.brainmentors.apps.firstspringbootappdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstspringbootappdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
