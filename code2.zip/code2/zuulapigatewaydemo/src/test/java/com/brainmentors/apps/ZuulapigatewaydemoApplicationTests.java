package com.brainmentors.apps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulapigatewaydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
