package com.brainmentors.apps;

public interface MySecurityConstants {
	
	String JWT_SECRET_KEY = "AQbcd5345AAAAABDDHFJR112QSDFRTHGK";
	String JWT_TOKEN_HEADER = "Authorization";
	String USER_NAME = "username";
	String AUTHORITIES = "authorities";

}
