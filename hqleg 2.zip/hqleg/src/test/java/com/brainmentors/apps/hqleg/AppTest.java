package com.brainmentors.apps.hqleg;



/**
 * Unit test for simple App.
 */
public class AppTest {
    
}
