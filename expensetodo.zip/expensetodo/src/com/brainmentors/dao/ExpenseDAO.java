package com.brainmentors.dao;

public class ExpenseDAO {

}
