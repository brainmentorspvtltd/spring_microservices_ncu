package com.brainmentors.dao;

import javax.persistence.Entity;

@Entity
public class Expense {

}
